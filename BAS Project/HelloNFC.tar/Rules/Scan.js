/**
 * Describe this function...
 * @param {IClientAPI} clientAPI
 */

export default function Scan(clientAPI) {
    try {   
      // Create instance native iOS nfc scanning class
      var _iOSNFCScanControl = NFCScanningControlBridge.new();
  
      // Callback function with nfc tag uid
      _iOSNFCScanControl.onNFCFoundCallback = (tagUID) => {
         alert("Tag found: " + tagUID );
      }
    } catch (err) {
      alert("errer" + err)
    };
  }